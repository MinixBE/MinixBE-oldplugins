<?php

namespace MinixBE\task;

use MinixBE\GameAPI;
use pocketmine\scheduler\Task;

class WartelobbyTask extends Task{

    public $plugin;

    public function __construct(GameAPI $plugin){
        $this->plugin = $plugin;
    }

    public function onRun(int $currentTick){
        $onlinePlayer = $this->plugin->getServer()->getOnlinePlayers();
        if ($onlinePlayer < 2){
            $this->plugin->getServer()->broadcastTip("wait..");
        }
    }
}