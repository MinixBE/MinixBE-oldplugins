<?php

namespace MinixBE;

use jojoe77777\FormAPI\SimpleForm;
use MinixBE\task\WartelobbyTask;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class GameAPI extends PluginBase implements Listener{

    public $prefix = "§r§fGameAPI §8|§7 ";

    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getScheduler()->scheduleRepeatingTask(new WartelobbyTask($this), 10);
        if (!is_file("/home/minixbe/cloud/player/gameapi/maps/map1.yml")){
            $config = new Config("/home/minixbe/cloud/player/gameapi/maps/map1.yml", Config::YAML);
            $config->set("x1", "0");
            $config->set("y1", "0");
            $config->set("z1", "0");
            $config->set("x2", "0");
            $config->set("y2", "0");
            $config->set("z2", "0");
            $config->save();
        }elseif (!is_file($this->getDataFolder() . "game.yml")){
            $config = new Config($this->getDataFolder() . "game.yml", Config::YAML);
            $config->set("wartelobby", "360");
            $config->set("gametime", "3600");
            $config->save();
        }
    }

    public function onLogin(PlayerPreLoginEvent $event){
        $player = $event->getPlayer();
        if (!is_file("/home/minixbe/cloud/player/gameapi/" . $player->getName() . ".yml")){
            $config = new Config("/home/minixbe/cloud/player/gameapi/" . $player->getName() . ".yml", Config::YAML);
            $config->set("kills", "0");
            $config->set("deaths", "0");
            $config->set("wins", "0");
            $config->save();
        }
    }

    public function onJoin(PlayerJoinEvent $event){
        $player = $event->getPlayer();
        $event->setJoinMessage($this->prefix . $player->getName() . " hat die Runde betreten.");
        $player->getInventory()->setItem(4, Item::get(Item::REDSTONE_TORCH)->setCustomName("§r§bEinstellungen"));
        $player->setXpLevel(60);
        $player->setMaxHealth(2);
    }

    public function getSettingsUI(PlayerInteractEvent $event){
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand();
        if ($item->getId() == Item::REDSTONE_TORCH){
            $this->sendSettingsUI($player);
        }
    }

    public function sendSettingsUI($player){
        $form = new SimpleForm(function (Player $player, int $data = null){
            $result = $data;
            if ($result == null){
                return true;
            }
            switch ($result){
                case 0:
                    break;
                case 1:
                    $this->sendStatsUI($player);
                    break;
            }
        });
        $form->setTitle("§r§bEinstellungen");
        $form->setContent("§r§7Wähle eine Option");
        $form->addButton("§r§cSchließen");
        $form->addButton("§r§6Stats §7BETA");
        $form->sendToPlayer($player);
    }

    public function sendStatsUI($player){
        $form = new SimpleForm(function (Player $player, int $data = null){
            $result = $data;
            if ($result == null){
                return true;
            }
            switch ($result){
                case 0:
                    break;
            }
        });
        $config = new Config("/home/minixbe/cloud/player/gameapi/" . $player->getName() . ".yml", Config::YAML);
        $form->setTitle("§r§6Stats §7BETA");
        $form->setContent("§r§7Test | Kills = " . $config->get("kills"));
        $form->addButton("§r§cSchließen");
        $form->sendToPlayer($player);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool{
        if ($command->getName() == "stats"){
            $this->sendStatsUI($sender);
        }elseif ($command->getName() == "start" and $sender->hasPermission("minixbe.start" or $sender->isOp())){
            $sender->sendMessage($this->prefix . "Error404 (der command exestiert nd hehe)");
        }
        return true;
    }
}