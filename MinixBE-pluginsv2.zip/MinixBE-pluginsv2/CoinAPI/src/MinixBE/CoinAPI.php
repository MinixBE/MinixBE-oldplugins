<?php

namespace MinixBE;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class CoinAPI extends PluginBase implements Listener{

    public $prefix = "§r§6MinixBE §8|§7 ";

    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onLogin(PlayerPreLoginEvent $event){
        $player = $event->getPlayer();
        if (!is_file("/home/minixbe/cloud/player/coins/" . $player->getName() . ".yml")){
            $config = new Config("/home/minixbe/cloud/player/coins/" . $player->getName() . ".yml", Config::YAML);
            $config->set("coins", "100");
            $config->save();
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool{
        $config = new Config("/home/minixbe/cloud/player/coins/" . $sender->getName() . ".yml", Config::YAML);
        if ($command->getName() == "coin" and $sender instanceof Player){
            $sender->sendMessage($this->prefix . "Du hast §6" . $config->get("coins") . " §7Coins.");
        }
        return true;
    }
}