<?php

namespace MinixBE;

use pocketmine\plugin\PluginBase;

class Broadcast extends PluginBase{

    public function onEnable(){
        $this->getScheduler()->scheduleRepeatingTask(new BroadcastTask($this), 1600);
    }
}