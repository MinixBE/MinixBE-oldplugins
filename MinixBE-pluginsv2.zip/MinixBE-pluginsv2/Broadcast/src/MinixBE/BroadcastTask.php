<?php

namespace MinixBE;

use pocketmine\scheduler\Task;
use pocketmine\utils\Config;

class BroadcastTask extends Task{

    public $plugin;

    public function __construct(Broadcast $plugin){
        $this->plugin = $plugin;
    }

    public function onRun(int $currentTick){
        if (!is_file("/home/minixbe/cloud/multibroadcast/messages.yml")){
            $config = new Config("/home/minixbe/cloud/multibroadcast/messages.yml");
            $config->set("Message", "§r§6MinixBE§8 |§7 Du kannst dir ein Rang unter §8shop.MinixBE.de§7 kaufen.");
            $config->save();
        }
        $config = new Config("/home/minixbe/cloud/multibroadcast/messages.yml", Config::YAML);
        $this->plugin->getServer()->broadcastMessage($config->get("Message"));
    }
}