<?php

namespace MinixBE;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class GroupSystem extends PluginBase implements Listener{

    public $prefix = "§6MinixBE §8|§7 ";

    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onLogin(PlayerPreLoginEvent $event){
        $player = $event->getPlayer();
        if (!file_exists("/home/minixbe/cloud/player/" . $player->getName() . ".yml")){
            $config = new Config("/home/minixbe/cloud/player/" . $player->getName() . ".yml", Config::YAML);
            $config->set("rang", "Spieler");
            $config->set("nick", "");
            $config->save();
        }
    }

    public function onJoin(PlayerJoinEvent $event){
        $player = $event->getPlayer();
        $this->rang($player);
        $this->setPermissions($player);
    }

    public function rang(Player $player){
        $config = new Config("/home/minixbe/cloud/player/" . $player->getName() . ".yml", Config::YAML);
        if (file_exists("/home/minixbe/cloud/player/" . $player->getName() . ".yml")){
            if ($config->get("rang") == "Admin"){
                if ($config->get("nick") == ""){
                    $player->setDisplayName("§r§4" . $player->getName());
                }else{
                    $player->setDisplayName("§r§7". $config->get("nick"));
                }
            }elseif ($config->get("rang") == "Developer"){
                if ($config->get("nick") == ""){
                    $player->setDisplayName("§r§3" . $player->getName());
                }else{
                    $player->setDisplayName("§r§3" . $config->get("nick"));
                }
            }elseif ($config->get("rang") == "Supporter"){
                if ($config->get("nick") == ""){
                    $player->setDisplayName("§r§9" . $player->getName());
                }else{
                    $player->setDisplayName("§r§3" . $config->get("nick"));
                }
            }elseif ($config->get("rang") == "Builder"){
                if ($config->get("nick") == ""){
                    $player->setDisplayName("§r§b" . $player->getName());
                }else{
                    $player->setDisplayName("§r§7" . $config->get("nick"));
                }
            }elseif ($config->get("rang") == "YouTuber"){
                if ($config->get("nick") == ""){
                    $player->setDisplayName("§r§5" . $player->getName());
                }else{
                    $player->setDisplayName("§r§7" . $config->get("nick"));
                }
            }elseif ($config->get("rang") == "Premium"){
                if ($config->get("nick") == ""){
                    $player->setDisplayName("§r§6" . $player->getName());
                }else{
                    $player->setDisplayName("§r§7" . $config->get("nick"));
                }
            }elseif ($config->get("rang") == "Spieler"){
                $player->setDisplayName("§r§7" . $player->getName());
            }
        }
    }

    public function chat(PlayerChatEvent $event){
        $player = $event->getPlayer();
        $config = new Config("/home/minixbe/cloud/player/" . $player->getName() . ".yml", Config::YAML);
        if ($config->get("rang") == "Admin"){
            if ($config->get("nick") == ""){
                $event->setFormat("§r§4Admin §8|§4 " . $player->getName() . " §8»§f " . $event->getMessage());
            }else{
                $event->setFormat("§r§7Spieler §8|§7 " . $config->get("nick") . " §8»§7 ". $event->getMessage());
            }
        }elseif ($config->get("rang") == "Developer"){
            if ($config->get("nick") == ""){
                $event->setFormat("§r§3Developer §8|§3 " . $player->getName() . " §8»§f " . $event->getMessage());
            }else{
                $event->setFormat("§r§7Spieler §8|§7 " . $config->get("nick") . " §8»§7 ". $event->getMessage());
            }
        }elseif ($config->get("rang") == "Supporter"){
            if ($config->get("nick") == ""){
                $event->setFormat("§r§9Supporter §8|§9 " . $player->getName() . " §8»§f " . $event->getMessage());
            }else{
                $event->setFormat("§r§7Spieler §8|§7 " . $config->get("nick") . " §8»§7 ". $event->getMessage());
            }
        }elseif ($config->get("rang") == "Builder"){
            if ($config->get("nick") == ""){
                $event->setFormat("§r§bBuilder §8|§b " . $player->getName() . " §8»§f " . $event->getMessage());
            }else{
                $event->setFormat("§r§7Spieler §8|§7 " . $config->get("nick") . " §8»§7 ". $event->getMessage());
            }
        }elseif ($config->get("rang") == "YouTuber"){
            if ($config->get("nick") == ""){
                $event->setFormat("§r§5YouTube §8|§5 " . $player->getName() . " §8»§7 " . $event->getMessage());
            }else{
                $event->setFormat("§r§7Spieler §8|§7 " . $config->get("nick") . " §8»§7 ". $event->getMessage());
            }
        }elseif ($config->get("rang") == "Premium"){
            if ($config->get("nick") == ""){
                $event->setFormat("§r§6Premium §8|§6 " . $player->getName() . " §8»§7 " . $event->getMessage());
            }else{
                $event->setFormat("§r§7Spieler §8|§7 " . $config->get("nick") . " §8»§7 ". $event->getMessage());
            }
        }elseif ($config->get("rang") == "Spieler"){
            $event->setFormat("§r§7Spieler §8|§7 " . $player->getName() . " §8»§7 ". $event->getMessage());
        }
    }

    public function setPermissions(Player $player){
        $config = new Config("/home/minixbe/cloud/player/" . $player->getName() . ".yml", Config::YAML);
        if ($config->get("rang") == "Admin"){
            $player->addAttachment($this)->setPermission("*", true);
        }elseif ($config->get("rang") == "Developer"){
            $player->addAttachment($this)->setPermission("minixbe.nick", true);
        }elseif ($config->get("rang") == "Supporter"){
            $player->addAttachment($this)->setPermission("minixbe.nick", true);
        }elseif ($config->get("rang") == "Builder"){
            $player->addAttachment($this)->setPermission("minixbe.nick", true);
        }elseif ($config->get("rang") == "YouTuber"){
            $player->addAttachment($this)->setPermission("minixbe.nick", true);
        }elseif ($config->get("rang") == "Premium"){
            $player->addAttachment($this)->setPermission("minixbe.nick", true);
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool{
        if ($command->getName() == "nick" and $sender->hasPermission("minixbe.nick") or $sender->isOp()){
            $this->setNick($sender);
        }
        return true;
    }

    public function setNick(Player $player){
        $config = new Config("/home/minixbe/cloud/player/" . $player->getName() . ".yml", Config::YAML);
        $nicks = ["dieserdadyt", "xXPornHubXx", "xXTMSPlayerXx", "LeanderIstUltraCoolXD", "WeLoveMinixBE", "HyroxIsKuhly", "xImNotYour5G", "byVölek"];
        if ($config->get("nick") == "" and count($nicks) != 0){
            $count = mt_rand(0, count($nicks) - 1);
            $nick = $nicks[$count];
            $config->set("nick", $nick);
            $config->save();
            $player->sendMessage($this->prefix . "Du bist nun als " . $config->get("nick") . " genickt.");
        }else{
            $config->set("nick", "");
            $config->save();
            $player->sendMessage($this->prefix . "Du bist nun entnickt.");
        }
    }
}