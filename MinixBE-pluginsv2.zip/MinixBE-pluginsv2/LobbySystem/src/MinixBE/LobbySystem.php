<?php

namespace MinixBE;

use jojoe77777\FormAPI\SimpleForm;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;

class LobbySystem extends PluginBase implements Listener{

    public $prefix = "§6MinixBE §8|§7 ";

    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onJoin(PlayerJoinEvent $event){
        $player = $event->getPlayer();
        $event->setJoinMessage($this->prefix . $player->getDisplayName() . " hat den Server betreten.");
        $player->getInventory()->setItem(0, Item::get(Item::BLAZE_ROD)->setCustomName("§r§dSpieler verstecken"));
        $player->getInventory()->setItem(4, Item::get(Item::COMPASS)->setCustomName("§r§dTeleporter"));
        $player->getInventory()->setItem(8, Item::get(Item::CHEST)->setCustomName("§r§dGadgets"));
        if ($player->hasPermission("minixbe.pitems") or $player->isOp()){
            $player->getInventory()->setItem(2, Item::get(Item::BONE)->setCustomName("§r§6PREMIUM Item"));
            $player->getInventory()->setItem(6, Item::get(Item::NAMETAG)->setCustomName("§r§6Nick Tool"));
        }
        $player->setXpLevel(2020);
        $player->setMaxHealth(6);
    }

    public function onQuit(PlayerQuitEvent $event){
        $player = $event->getPlayer();
        $event->setQuitMessage($this->prefix . $player->getDisplayName() . " hat das Spiel verlassen.");
    }

    public function setItems(PlayerInteractEvent $event){
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand();
        if ($item->getId() == Item::BLAZE_ROD){
            foreach ($this->getServer()->getOnlinePlayers() as $onlinePlayer){
                $player->hidePlayer($onlinePlayer);
            }
            $player->sendMessage($this->prefix . "Du hast alle Spieler versteckt.");
            $player->getInventory()->remove(Item::get(Item::BLAZE_ROD));
            $player->getInventory()->setItem(0, Item::get(Item::STICK)->setCustomName("§r§bSpieler anzeigen"));
        }elseif ($item->getId() == Item::STICK){
            foreach ($this->getServer()->getOnlinePlayers() as $onlinePlayer){
                $player->showPlayer($onlinePlayer);
            }
            $player->sendMessage($this->prefix . "Du kannst nun alle Spieler wieder sehen.");
            $player->getInventory()->remove(Item::get(Item::STICK));
            $player->getInventory()->setItem(0, Item::get(Item::BLAZE_ROD)->setCustomName("§r§dSpieler verstecken"));
        }elseif ($item->getId() == Item::COMPASS){
            $this->openCompassUI($player);
        }elseif ($item->getId()  == Item::CHEST){
            $this->openGadgetsUI($player);
        }elseif ($item->getId() == Item::BONE){
            $player->addTitle("", "§r§csoon");
        }elseif ($item->getId() == Item::NAMETAG){
            $player->getServer()->dispatchCommand($player, "nick");
        }
    }

    public function openCompassUI($player){
        $form = new SimpleForm(function (Player $player, int $data = null){
            $result = $data;
            if ($result == null){
                return true;
            }
            switch ($result){
                case 0:
                    break;
                case 1:
                    $player->teleport(new Position(0, 0, 0));
                    break;
                case 2:
                    $player->teleport(new Position(0, 0, 0));
                    break;
                case 3:
                    $player->teleport(new Position(0, 0, 0));
                    break;
            }
        });
        $form->setTitle("§r§bTeleporter");
        $form->setContent("§r§7Wähle ein Minigame");
        $form->addButton("§r§cSchließen");
        $form->addButton("§r§3BuildFFA", 0, "textures/blocks/sandstone");
        $form->addButton("§r§21vs1", 0, "textures/items/gold_sword");
        $form->addButton("§r§bCores", 0, "textures/blocks/beacon");
        $form->sendToPlayer($player);
        return $form;
    }

    public function openGadgetsUI($player){
        $form = new SimpleForm(function (Player $player, int $data = null){
            $result = $data;
            if ($result == null){
                return true;
            }
            switch ($result){
                case 0:
                    break;
            }
        });
        $form->setTitle("§r§dGadgets");
        $form->setContent("§r§7Wähle ein Gadget aus");
        $form->addButton("§r§cSchließen");
        $form->sendToPlayer($player);
        return $form;
    }

    public function onRespawn(PlayerRespawnEvent $event){
        $player->getInventory()->setItem(0, Item::get(Item::BLAZE_ROD)->setCustomName("§r§dSpieler verstecken"));
        $player->getInventory()->setItem(4, Item::get(Item::COMPASS)->setCustomName("§r§7Teleporter"));
        $player->getInventory()->setItem(8, Item::get(Item::CHEST)->setCustomName("§r§dGadgets"));
        if ($player->hasPermission("minixbe.pitems") or $player->isOp()){
            $player->getInventory()->setItem(2, Item::get(Item::BONE)->setCustomName("§r§6PREMIUM Item"));
            $player->getInventory()->setItem(6, Item::get(Item::NAMETAG)->setCustomName("§r§6Nick Tool"));
        }
    }

    public function onFly(Player $player){
        if ($player->isOp() or $player->hasPermission("minixbe.fly")){
            $player->setAllowFlight(true);
        }
    }

    public function onHunger(PlayerExhaustEvent $event){
        $event->setCancelled(true);
    }

    public function onDamage(EntityDamageEvent $event){
        $event->setCancelled(true);
    }

    public function onBreak(BlockBreakEvent $event){
        $event->setCancelled(true);
    }

    public function onDrop(PlayerDropItemEvent $event){
        $event->setCancelled(true);
    }

    public function onInvTransaction(InventoryTransactionEvent $event){
        $event->setCancelled(true);
    }

    public function onPickup(InventoryPickupItemEvent $event){
        $event->setCancelled(true);
    }

    public function onPlace(BlockPlaceEvent $event){
        $event->setCancelled(true);
    }
}