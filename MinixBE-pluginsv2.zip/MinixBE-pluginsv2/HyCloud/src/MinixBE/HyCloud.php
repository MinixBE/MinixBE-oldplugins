<?php

namespace MinixBE;

use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class HyCloud extends PluginBase implements Listener{

    public $prefix = "§r§6Cloud §8|§7 ";

    public function onEnable(){
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onWartungarbeiten(Player $player){
        if (!is_file("/home/minixbe/cloud/server/")){
            $config = new Config("/home/minixbe/cloud/server/" . "server.yml", Config::YAML);
            $config->set("online", true);
            $config->save();
        }
        $config = new Config("/home/minixbe/cloud/server/" . "server.yml", Config::YAML);
        if ($config->get("online") == false){
            $player->kick(
                "§r§6MinixBE §cist derzeit in Wartungsarbeiten! \n" .
                "§r§7Discord§8:§7 MinixBE.de\discord \n" .
                "§r§bTwitter§8: §7@MinixBEde", false
            );
        }
    }
}